<?php

/**
 * Copyright 2013 Go Daddy Operating Company, LLC. All Rights Reserved.
 */

header( 'Status: 404 Not found' ); ?>
Not found
