<?php

namespace WPaaS;

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

final class Hotfixes {

	/**
	 * Class constructor.
	 */
	public function __construct() {

		/**
		 * WP Easy Mode.
		 *
		 * Add a checkbox to the Settings step for ProConnect.
		 */
		add_filter( 'wpem_step_settings_fields', function( $fields ) {

			$fields[] = [
				'name'        => 'wpem_pro_opt_in',
				'type'        => 'checkbox',
				'sanitizer'   => 'absint',
				'value'       => 1,
				'default'     => 0,
				'required'    => false,
				'skip_option' => true,
				'choices'     => [
					__( 'I would be interested in hiring a professional to help me with my WordPress site.', 'gd-system-plugin' ),
				],
			];

			return $fields;

		} );

		/**
		 * WP Easy Mode.
		 *
		 * Deactivate all plugins on quit, except WP101.
		 */
		add_filter( 'wpem_deactivate_plugins_on_quit', function( $plugins ) {

			if ( ! function_exists( 'get_plugins' ) ) {

				require_once ABSPATH . 'wp-admin/includes/plugin.php';

			}

			$plugins = get_plugins();

			unset( $plugins['wp101-video-tutorial/wp101-video-tutorial.php'] );

			return array_keys( $plugins );

		} );

		/**
		 * WP Popular Posts.
		 *
		 * This makes it perform much better especially on high traffic sites.
		 */
		add_filter( 'wpp_data_sampling', '__return_true' );

		/**
		 * Limit Login Attempts.
		 */
		add_filter( 'pre_update_option_limit_login_lockouts',      [ $this, 'clean_limit_login_attempts' ], PHP_INT_MAX );
		add_filter( 'pre_update_option_limit_login_retries_valid', [ $this, 'clean_limit_login_attempts' ], PHP_INT_MAX );
		add_filter( 'pre_update_option_limit_login_retries',       [ $this, 'clean_limit_login_attempts' ], PHP_INT_MAX );
		add_filter( 'pre_update_option_limit_login_logged',        [ $this, 'clean_limit_login_attempts' ], PHP_INT_MAX );

		/**
		 * Jetpack.
		 */
		if ( Plugin::is_staging_site() ) {

			// Prevent identity crisis from triggering on staging sites
			add_filter( 'jetpack_has_identity_crisis', '__return_false', PHP_INT_MAX );

		}

		add_filter( 'option_jetpack_options', [ $this, 'remove_jetpack_nag' ], PHP_INT_MAX );

		/**
		 * WP-Cron.
		 */
		if ( defined( 'WP_CLI' ) && WP_CLI ) {

			$this->blacklist_cron_event_hooks();

		}

	}

	/**
	 * Clean up options for Limit Login Attempts.
	 *
	 * On very active sites these can become massive
	 * arrays that turn into massive strings and break
	 * MySQL because of packet size limitations.
	 *
	 * @param  array $value
	 *
	 * @return array
	 */
	public function clean_limit_login_attempts( array $value ) {

		if ( count( $value ) < 250 ) {

			return $value;

		}

		$sorting_func = function( $a, $b ) {

			if ( is_array( $b ) ) {

				if ( count( $a ) == count( $b ) ) {

					return 0;

				}

				return ( count( $a ) < count( $b ) ) ? - 1 : 1;

			}

			if ( $a == $b ) {

				return 0;

			}

			return ( $a < $b ) ? -1 : 1;

		};

		uasort( $value, $sorting_func );

		return array_slice( $value, -200 );

	}

	/**
	 * Hide the Jetpack updates screen nag.
	 *
	 * @param  array $value
	 *
	 * @return array
	 */
	public function remove_jetpack_nag( array $value ) {

		if ( $value && empty( $value['hide_jitm']['manage'] ) || 'hide' !== $value['hide_jitm']['manage'] ) {

			$value['hide_jitm']['manage'] = 'hide';

		}

		return $value;

	}

	/**
	 * Blacklist cron event hooks.
	 *
	 * Note: Should only run when using WP-CLI.
	 */
	private function blacklist_cron_event_hooks() {

		global $wpdb, $wpaas_cron_event_temp_blacklist;

		$blacklist = [
			'wp_version_check',
		];

		// Get temporary blacklist transients
		$transients = (array) $wpdb->get_results(
			"SELECT
			option_name,
			option_value
			FROM {$wpdb->options}
			WHERE option_name
			LIKE '_transient_wpaas_skip_cron_%';"
		);

		// Scrub array of key prefixes and expired transients
		foreach ( $transients as $key => $transient ) {

			$transients[ $key ]->option_name = preg_filter( '/^_transient_/', '', $transient->option_name );

			if ( false === get_transient( $transient->option_name ) ) {

				unset( $transients[ $key ] );

			}

		}

		// Store in global, used by 'cron event wpaas reset' subcommand
		$wpaas_cron_event_temp_blacklist = array_combine(
			wp_list_pluck( $transients, 'option_name' ),
			wp_list_pluck( $transients, 'option_value' )
		);

		// Merge temporary blacklist into core blacklist
		$blacklist = array_merge( $blacklist, array_values( $wpaas_cron_event_temp_blacklist ) );

		// Remove blacklisted events from the crons array
		add_filter( 'option_cron', function( $crons ) use ( $blacklist ) {

			if ( ! $crons ) {

				return $crons;

			}

			foreach ( (array) $crons as $timestamp => $events ) {

				foreach ( (array) $events as $hook => $event ) {

					if ( in_array( $hook, $blacklist ) ) {

						unset( $crons[ $timestamp ][ $hook ] );

					}

				}

				if ( ! $events ) {

					unset( $crons[ $timestamp ] );

				}

			}

			return (array) $crons;

		}, PHP_INT_MAX );

	}

}
