<div class="cupg_preview_wrapper">
    <?= $fancybox->create(); ?>
</div>