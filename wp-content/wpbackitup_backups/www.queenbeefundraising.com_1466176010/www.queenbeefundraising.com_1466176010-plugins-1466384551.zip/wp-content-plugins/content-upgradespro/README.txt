=== content-upgrades-pro ===
Tags: content upgrades, content, wordpress plugin, upgrades, Aweber, MailChimp, GetResponse, OntraPort
Donate link: http://contentupgradespro.com/
Requires at least: 3.5
Tested up to: 4.5
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A premium plugin for creating \"content upgrades\". Create unlimited number of "content upgrades" with different designs and settings.

== Installation ==
**To install the plugin manually in WordPress:**

1. Login as Admin on your WordPress blog.
2. Click on the \"Plugins\" tab in the left menu.
3. Select \"Add New\"
4. Click on \"Upload\" at the top of the page.
5. Select \'content-upgrades.zip\' on your computer, and upload. Activate the plugin once it is uploaded.

**To install the plugin manually with FTP:**

1. Unzip \'content-upgrades.zip\' file. Upload that folder to the \'/wp-content/plugins/\' directory.
2. Login to your WordPress dashboard and activate the plugin through the \"Plugins\" tab in the left menu.

== Frequently Asked Questions ==
If you have any questions, please check our website and fill free to contact directly.

== Changelog ==
==2.0.2==
*Updated connection with emailing services
*Minor fixes

==2.0.1==
*Optimized pop-up generation on public side

==2.0==
*New plugin's menu design
*Brand new pop-up designs
*Use of custom images in pop-ups
*Optional "Name" field for pop-ups
*Tens of new, mind-blowing, customizable fancy boxes
*More options for site-wide pop-up display
*Optimized performance
*Totally awesome new "Bonuses Depot" feature
*Mobile version of pop-ups

= 1.9 =
* new feature: sitewide pop-up to present your big opt-in bribe
* new feature: text alignment inside your fancy boxes
* minor bug fixes
* minor performance optimizations

= 1.8 =
* new feature: subscription without bonus content
* new feature: pre-filled fields in pop-ups for those who already subscribed
* optimized performance
* improved compatibility with major WP themes and builders
* improved \“custom email\” delivery algorithm
* improved \“send subscribers to your email\” performance
* more accurate statistics count for multiple content upgrades on a single page
* improved update notification and procedure
* minor bug fixes