<div id="nf-form-<?php echo $form_id; ?>-cont" class="nf-form-cont">
    
    <div class="nf-loading-spinner"></div>

</div>