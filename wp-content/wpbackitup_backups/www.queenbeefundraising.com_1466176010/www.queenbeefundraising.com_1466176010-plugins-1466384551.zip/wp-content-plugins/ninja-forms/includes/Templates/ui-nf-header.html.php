<div id="nf-header">
    <div id="nf-app-header">
        <div id="nf-logo"></div>
        <ul>
            <li><a href="#">Form Fields</a></li>
            <li><a href="#">Emails & Actions</a></li>
            <li><a href="#">Settings</a></li>
            <li><a class="preview" href="#">Preview Changes<span class="dashicons dashicons-visibility"></span></a></li>
        </ul>
        <input class="nf-button primary" type="submit" value="Save" />
        <a class="nf-mobile" href="#"><span class="dashicons dashicons-editor-ul"></span></a>
        <a class="nf-cancel" href="#">Cancel</a>
    </div>

    <div id="nf-app-sub-header">

        <a class="nf-add-new" href="#">Add new field</a>
        <h2>Contact Form</h2>

        <!-- <input class="nf-button secondary" type="submit" value="Edit Emails and Actions" /> -->

    </div>

</div>
