-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:02
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_coupg_statistic
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_coupg_statistic LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_coupg_statistic`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_coupg_statistic`;
CREATE TABLE `wp_fsyt4wavdq_coupg_statistic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coupg_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `wp_fsyt4wavdq_coupg_statistic_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `wp_fsyt4wavdq_coupg_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Data for table `wp_fsyt4wavdq_coupg_statistic`
--




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
