-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:01
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_nf3_field_meta
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_nf3_field_meta LIMIT 0,10000
-- Offset : 0
-- Rows   : 172
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_nf3_field_meta`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_nf3_field_meta`;
CREATE TABLE `wp_fsyt4wavdq_nf3_field_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `key` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_fsyt4wavdq_nf3_field_meta`
--
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("1","1","objectType","Field");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("2","1","objectDomain","fields");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("3","1","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("4","1","label_pos","above");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("5","1","required","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("6","1","placeholder","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("7","1","default","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("8","1","wrapper_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("9","1","element_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("10","1","input_limit","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("11","1","input_limit_type","characters");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("12","1","input_limit_message","Character(s) left");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("13","1","manual_key","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("14","1","disable_input","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("15","1","admin_label","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("16","1","help_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("17","1","desc_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("18","1","desc_pos","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("19","1","disable_browser_autocomplete","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("20","1","mask","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("21","1","custom_mask","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("22","1","order","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("23","2","objectType","Field");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("24","2","objectDomain","fields");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("25","2","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("26","2","label_pos","above");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("27","2","required","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("28","2","default","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("29","2","placeholder","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("30","2","wrapper_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("31","2","element_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("32","2","admin_label","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("33","2","help_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("34","2","desc_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("35","2","desc_pos","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("36","2","order","2");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("37","3","objectType","Field");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("38","3","objectDomain","fields");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("39","3","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("40","3","label_pos","above");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("41","3","required","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("42","3","placeholder","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("43","3","default","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("44","3","wrapper_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("45","3","element_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("46","3","input_limit","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("47","3","input_limit_type","characters");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("48","3","input_limit_message","Character(s) left");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("49","3","manual_key","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("50","3","disable_input","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("51","3","admin_label","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("52","3","help_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("53","3","desc_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("54","3","desc_pos","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("55","3","disable_browser_autocomplete","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("56","3","textarea_rte","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("57","3","disable_rte_mobile","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("58","3","textarea_media","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("59","3","order","3");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("60","4","objectType","Field");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("61","4","objectDomain","fields");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("62","4","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("63","4","label_pos","above");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("64","4","required","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("65","4","placeholder","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("66","4","default","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("67","4","wrapper_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("68","4","element_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("69","4","input_limit","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("70","4","input_limit_type","characters");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("71","4","input_limit_message","Character(s) left");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("72","4","manual_key","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("73","4","disable_input","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("74","4","admin_label","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("75","4","help_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("76","4","desc_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("77","4","desc_pos","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("78","4","spam_answer","7");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("79","4","order","4");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("87","6","order","9999");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("88","6","objectType","Field");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("89","6","objectDomain","fields");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("90","6","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("91","6","processing_label","Processing");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("92","6","wrapper_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("93","6","element_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("94","7","objectType","Field");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("95","7","objectDomain","fields");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("96","7","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("97","7","label_pos","above");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("98","7","required","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("99","7","placeholder","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("100","7","default","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("101","7","wrapper_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("102","7","element_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("103","7","input_limit","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("104","7","input_limit_type","characters");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("105","7","input_limit_message","Character(s) left");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("106","7","manual_key","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("107","7","disable_input","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("108","7","admin_label","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("109","7","help_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("110","7","desc_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("111","7","desc_pos","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("112","7","disable_browser_autocomplete","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("113","7","mask","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("114","7","custom_mask","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("115","7","order","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("116","8","objectType","Field");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("117","8","objectDomain","fields");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("118","8","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("119","8","label_pos","above");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("120","8","required","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("121","8","default","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("122","8","placeholder","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("123","8","wrapper_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("124","8","element_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("125","8","admin_label","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("126","8","help_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("127","8","desc_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("128","8","desc_pos","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("129","8","order","2");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("130","9","objectType","Field");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("131","9","objectDomain","fields");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("132","9","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("133","9","label_pos","above");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("134","9","required","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("135","9","placeholder","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("136","9","default","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("137","9","wrapper_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("138","9","element_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("139","9","input_limit","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("140","9","input_limit_type","characters");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("141","9","input_limit_message","Character(s) left");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("142","9","manual_key","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("143","9","disable_input","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("144","9","admin_label","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("145","9","help_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("146","9","desc_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("147","9","desc_pos","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("148","9","disable_browser_autocomplete","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("149","9","textarea_rte","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("150","9","disable_rte_mobile","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("151","9","textarea_media","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("152","9","order","3");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("153","10","objectType","Field");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("154","10","objectDomain","fields");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("155","10","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("156","10","label_pos","above");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("157","10","required","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("158","10","placeholder","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("159","10","default","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("160","10","wrapper_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("161","10","element_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("162","10","input_limit","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("163","10","input_limit_type","characters");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("164","10","input_limit_message","Character(s) left");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("165","10","manual_key","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("166","10","disable_input","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("167","10","admin_label","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("168","10","help_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("169","10","desc_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("170","10","desc_pos","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("171","10","spam_answer","7");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("172","10","order","4");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("173","11","order","9999");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("174","11","objectType","Field");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("175","11","objectDomain","fields");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("176","11","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("177","11","processing_label","Processing");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("178","11","wrapper_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_field_meta VALUES("179","11","element_class","");




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
