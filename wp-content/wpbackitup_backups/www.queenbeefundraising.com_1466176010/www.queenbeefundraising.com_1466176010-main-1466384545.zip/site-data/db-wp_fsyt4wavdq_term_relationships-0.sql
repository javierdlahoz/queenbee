-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:01
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_term_relationships
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_term_relationships LIMIT 0,10000
-- Offset : 0
-- Rows   : 8
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_term_relationships`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_term_relationships`;
CREATE TABLE `wp_fsyt4wavdq_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_fsyt4wavdq_term_relationships`
--
INSERT IGNORE INTO wp_fsyt4wavdq_term_relationships VALUES("1","1","0");
INSERT IGNORE INTO wp_fsyt4wavdq_term_relationships VALUES("18","3","0");
INSERT IGNORE INTO wp_fsyt4wavdq_term_relationships VALUES("15","3","0");
INSERT IGNORE INTO wp_fsyt4wavdq_term_relationships VALUES("16","3","0");
INSERT IGNORE INTO wp_fsyt4wavdq_term_relationships VALUES("17","3","0");
INSERT IGNORE INTO wp_fsyt4wavdq_term_relationships VALUES("22","3","0");
INSERT IGNORE INTO wp_fsyt4wavdq_term_relationships VALUES("26","3","0");
INSERT IGNORE INTO wp_fsyt4wavdq_term_relationships VALUES("149","1","0");




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
