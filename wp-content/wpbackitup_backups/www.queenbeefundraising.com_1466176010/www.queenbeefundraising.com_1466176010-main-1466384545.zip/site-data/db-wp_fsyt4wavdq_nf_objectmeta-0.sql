-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:01
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_nf_objectmeta
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_nf_objectmeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 75
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_nf_objectmeta`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_nf_objectmeta`;
CREATE TABLE `wp_fsyt4wavdq_nf_objectmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `object_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) NOT NULL,
  `meta_value` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=utf8;



--
-- Data for table `wp_fsyt4wavdq_nf_objectmeta`
--
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("1","1","date_updated","2016-06-17");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("2","1","form_title","Contact Form");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("3","1","show_title","0");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("4","1","save_subs","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("5","1","logged_in","0");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("6","1","append_page","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("7","1","ajax","0");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("8","1","clear_complete","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("9","1","hide_complete","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("10","1","success_msg","Your form has been successfully submitted.");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("11","1","email_from","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("12","1","email_type","html");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("13","1","user_email_msg","Thank you so much for contacting us. We will get back to you shortly.");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("14","1","user_email_fields","0");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("15","1","admin_email_msg","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("16","1","admin_email_fields","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("17","1","admin_attach_csv","0");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("18","1","email_from_name","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("19","2","date_updated","2014-09-09");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("20","2","active","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("21","2","name","Email User");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("22","2","type","email");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("23","2","email_format","html");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("24","2","attach_csv","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("25","2","from_name","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("26","2","from_address","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("27","2","reply_to","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("28","2","to","field_2");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("29","2","cc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("30","2","bcc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("31","2","email_subject","Thank you for contacting us!");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("32","2","email_message","Thank you so much for contacting us. We will get back to you shortly.");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("33","2","redirect_url","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("34","2","success_message_loc","ninja_forms_display_before_fields");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("35","2","success_msg","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("36","3","date_updated","2014-09-09");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("37","3","active","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("38","3","name","Success Message");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("39","3","type","success_message");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("40","3","email_format","html");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("41","3","attach_csv","0");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("42","3","from_name","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("43","3","from_address","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("44","3","reply_to","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("45","3","to","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("46","3","cc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("47","3","bcc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("48","3","email_subject","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("49","3","email_message","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("50","3","redirect_url","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("51","3","success_message_loc","ninja_forms_display_after_fields");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("52","3","success_msg","Your form has been successfully submitted.");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("53","3","text_message_number","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("54","3","text_message_carrier","0");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("55","3","text_message_message","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("56","4","date_updated","2014-09-09");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("57","4","active","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("58","4","name","Email Admin");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("59","4","type","email");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("60","4","email_format","html");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("61","4","attach_csv","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("62","4","from_name","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("63","4","from_address","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("64","4","reply_to","field_2");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("65","4","to","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("66","4","cc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("67","4","bcc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("68","4","email_subject","Ninja Form Submission");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("69","4","email_message","[ninja_forms_all_fields]");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("70","4","redirect_url","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("71","4","success_message_loc","ninja_forms_display_before_fields");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("72","4","success_msg","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("73","4","text_message_number","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("74","4","text_message_carrier","0");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objectmeta VALUES("75","4","text_message_message","");




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
