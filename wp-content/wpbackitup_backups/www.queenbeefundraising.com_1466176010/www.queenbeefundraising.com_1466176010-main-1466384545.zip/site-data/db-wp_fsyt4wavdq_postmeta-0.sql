-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:01
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_postmeta
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_postmeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 87
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_postmeta`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_postmeta`;
CREATE TABLE `wp_fsyt4wavdq_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=183 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_fsyt4wavdq_postmeta`
--
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("1","2","_wp_page_template","default");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("4","2","_edit_lock","1466326012:1");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("5","2","_edit_last","1");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("6","9","_edit_lock","1463680961:3");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("7","9","_edit_last","3");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("8","11","_edit_lock","1463680955:3");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("9","11","_edit_last","3");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("10","13","_edit_lock","1463680966:3");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("11","13","_edit_last","3");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("12","15","_menu_item_type","post_type");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("13","15","_menu_item_menu_item_parent","0");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("14","15","_menu_item_object_id","13");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("15","15","_menu_item_object","page");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("16","15","_menu_item_target","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("17","15","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("18","15","_menu_item_xfn","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("19","15","_menu_item_url","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("50","22","_menu_item_type","post_type");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("21","16","_menu_item_type","post_type");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("22","16","_menu_item_menu_item_parent","0");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("23","16","_menu_item_object_id","11");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("24","16","_menu_item_object","page");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("25","16","_menu_item_target","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("26","16","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("27","16","_menu_item_xfn","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("28","16","_menu_item_url","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("49","19","_edit_last","3");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("30","17","_menu_item_type","post_type");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("31","17","_menu_item_menu_item_parent","0");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("32","17","_menu_item_object_id","9");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("33","17","_menu_item_object","page");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("34","17","_menu_item_target","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("35","17","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("36","17","_menu_item_xfn","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("37","17","_menu_item_url","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("48","19","_edit_lock","1463680953:3");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("39","18","_menu_item_type","post_type");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("40","18","_menu_item_menu_item_parent","0");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("41","18","_menu_item_object_id","2");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("42","18","_menu_item_object","page");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("43","18","_menu_item_target","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("44","18","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("45","18","_menu_item_xfn","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("46","18","_menu_item_url","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("51","22","_menu_item_menu_item_parent","0");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("52","22","_menu_item_object_id","19");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("53","22","_menu_item_object","page");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("54","22","_menu_item_target","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("55","22","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("56","22","_menu_item_xfn","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("57","22","_menu_item_url","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("59","23","_edit_lock","1463680963:3");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("60","23","_edit_last","3");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("61","26","_menu_item_type","post_type");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("62","26","_menu_item_menu_item_parent","0");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("63","26","_menu_item_object_id","23");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("64","26","_menu_item_object","page");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("65","26","_menu_item_target","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("66","26","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("67","26","_menu_item_xfn","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("68","26","_menu_item_url","");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("70","1","_edit_last","1");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("72","1","_edit_lock","1466325801:1");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("146","19","wpem_page","contact");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("145","2","wpem_page","about");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("147","11","wpem_page","estimates");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("148","9","wpem_page","faq");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("149","23","wpem_page","news");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("150","13","wpem_page","testimonials");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("154","140","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1080;s:6:\"height\";i:878;s:4:\"file\";s:84:\"2016/06/d288d822b73e03297f24d0dcd1c0bcbef89941f209f1415e76dfe0eaac98e6b0-v9k0Fb.jpeg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:84:\"d288d822b73e03297f24d0dcd1c0bcbef89941f209f1415e76dfe0eaac98e6b0-v9k0Fb-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:84:\"d288d822b73e03297f24d0dcd1c0bcbef89941f209f1415e76dfe0eaac98e6b0-v9k0Fb-300x244.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:244;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:84:\"d288d822b73e03297f24d0dcd1c0bcbef89941f209f1415e76dfe0eaac98e6b0-v9k0Fb-768x624.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:624;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:85:\"d288d822b73e03297f24d0dcd1c0bcbef89941f209f1415e76dfe0eaac98e6b0-v9k0Fb-1024x832.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:832;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"post-image\";a:4:{s:4:\"file\";s:84:\"d288d822b73e03297f24d0dcd1c0bcbef89941f209f1415e76dfe0eaac98e6b0-v9k0Fb-676x550.jpeg\";s:5:\"width\";i:676;s:6:\"height\";i:550;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("153","140","_wp_attached_file","2016/06/d288d822b73e03297f24d0dcd1c0bcbef89941f209f1415e76dfe0eaac98e6b0-v9k0Fb.jpeg");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("155","140","_wp_attachment_custom_header_last_used_hemingway","1466199704");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("156","140","_wp_attachment_is_custom_header","hemingway");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("165","147","coupg_header","15 Smart Tools To Get More Traffic & Sales From Twitter (While Saving Your Time)");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("172","148","_wp_attached_file","2016/06/woman-hand-desk-office.jpg");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("166","147","coupg_description","Enter your Name and E-mail address below to receive your free copy of this ebook.");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("167","147","coupg_button_text","GET IT NOW");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("168","147","coupg_default_name_text","Enter your Name...");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("169","147","coupg_default_email_text","Enter your E-mail...");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("170","147","coupg_privacy_statement","We guarantee 100% privacy. Your information will not be shared.");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("171","147","coupg_upg_location_page","-1");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("173","148","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:34:\"2016/06/woman-hand-desk-office.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"woman-hand-desk-office-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"woman-hand-desk-office-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"woman-hand-desk-office-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"woman-hand-desk-office-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:8:\"featured\";a:4:{s:4:\"file\";s:34:\"woman-hand-desk-office-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:34:\"woman-hand-desk-office-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"slider\";a:4:{s:4:\"file\";s:35:\"woman-hand-desk-office-1140x445.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:445;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("174","1","_thumbnail_id","148");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("177","149","_edit_last","1");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("178","149","_edit_lock","1466325935:1");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("179","149","_thumbnail_id","148");
INSERT IGNORE INTO wp_fsyt4wavdq_postmeta VALUES("182","2","_thumbnail_id","148");




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
