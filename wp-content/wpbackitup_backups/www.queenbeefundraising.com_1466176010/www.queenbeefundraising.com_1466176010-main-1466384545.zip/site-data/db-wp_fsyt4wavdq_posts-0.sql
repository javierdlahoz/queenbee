-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:01
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_posts
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_posts LIMIT 0,10000
-- Offset : 0
-- Rows   : 28
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_posts`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_posts`;
CREATE TABLE `wp_fsyt4wavdq_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_fsyt4wavdq_posts`
--
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("1","1","2016-06-17 14:41:42","2016-06-17 21:41:42","Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!","Hello world!","","publish","open","open","","hello-world","","","2016-06-19 01:45:34","2016-06-19 08:45:34","","0","http://www.queenbeefundraising.com/?p=1","0","post","","1");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("2","1","2016-06-17 14:41:42","2016-06-17 21:41:42","<strong>COMPANY NAME</strong> has been delivering results since we opened in <strong>YEAR</strong>. Our goal is to provide both a superior customer experience and tremendous value for our customers.\n\n<strong>OWNER NAME</strong> has over <strong>NUMBER</strong> years of experience in <strong>INDUSTRY NAME</strong> and is passionate about exceeding your expectations.\n\nWe love our customers and welcome your feedback and suggestions. Use our <a title=\"Contact Us\" href=\"/contact/\">Contact Us</a> page to tell us what we’re doing right or what we can improve on.","About Us","","publish","closed","closed","","about","","","2016-06-19 01:48:46","2016-06-19 08:48:46","","0","http://www.queenbeefundraising.com/?page_id=2","0","page","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("9","1","2016-06-17 14:41:42","2016-06-17 21:41:42","For your convenience, our most common customer questions are answered right here.\n\nNot finding what you want? Reach out directly through our <a href=\"/contact/\" title=\"Contact Us\">Contact Us</a> page.\n\n<strong>Q:</strong> <em>Add questions here.</em>\n\n<strong>A:</strong> Add answers here.","FAQ","","publish","closed","closed","","faq","","","2016-06-17 14:41:42","2016-06-17 21:41:42","","0","http://www.queenbeefundraising.com/?page_id=9","0","page","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("11","1","2016-06-17 14:41:42","2016-06-17 21:41:42","Save time with a free, no-obligation quote.\n\nTell us the details of your project, and we’ll respond with an accurate quote and timeline for the work.\n\nNeed something else? Use our <a title=\"Contact Us\" href=\"/contact/\">Contact Us</a> page.\n\n[ninja_forms id=2]","Estimates","","publish","closed","closed","","estimates","","","2016-06-17 14:41:42","2016-06-17 21:41:42","","0","http://www.queenbeefundraising.com/?page_id=11","0","page","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("13","1","2016-06-17 14:41:42","2016-06-17 21:41:42","Our wonderful customers are the reason we’re in business. Here are some of the great things they’ve said about us.\n\nWe’ll do everything we can to make sure you’re a satisfied customer, too!\n\n<blockquote>Insert an amazing testimonial here. &mdash; Jane Doe</blockquote>","Testimonials","","publish","closed","closed","","testimonials","","","2016-06-17 14:41:42","2016-06-17 21:41:42","","0","http://www.queenbeefundraising.com/?page_id=13","0","page","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("15","1","2016-06-17 14:41:42","2016-06-17 21:41:42"," ","","","publish","closed","closed","","15","","","2016-06-19 01:40:42","2016-06-19 08:40:42","","0","http://www.queenbeefundraising.com/?p=15","6","nav_menu_item","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("16","1","2016-06-17 14:41:42","2016-06-17 21:41:42"," ","","","publish","closed","closed","","16","","","2016-06-19 01:40:42","2016-06-19 08:40:42","","0","http://www.queenbeefundraising.com/?p=16","5","nav_menu_item","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("17","1","2016-06-17 14:41:42","2016-06-17 21:41:42"," ","","","publish","closed","closed","","17","","","2016-06-19 01:40:42","2016-06-19 08:40:42","","0","http://www.queenbeefundraising.com/?p=17","4","nav_menu_item","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("18","1","2016-06-17 14:41:42","2016-06-17 21:41:42"," ","","","publish","closed","closed","","18","","","2016-06-19 01:40:42","2016-06-19 08:40:42","","0","http://www.queenbeefundraising.com/?p=18","1","nav_menu_item","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("19","1","2016-06-17 14:41:42","2016-06-17 21:41:42","Customer feedback is the lifeblood of our business. Tell us what’s on your mind, good or bad.\n\nWe respond to all customer feedback and look forward to hearing from you!\n\n[ninja_forms id=1]","Contact Us","","publish","closed","closed","","contact","","","2016-06-17 14:41:42","2016-06-17 21:41:42","","0","http://www.queenbeefundraising.com/?page_id=19","0","page","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("22","1","2016-06-17 14:41:42","2016-06-17 21:41:42"," ","","","publish","closed","closed","","22","","","2016-06-19 01:40:42","2016-06-19 08:40:42","","0","http://www.queenbeefundraising.com/?p=22","2","nav_menu_item","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("23","1","2016-06-17 14:41:42","2016-06-17 21:41:42","","News","","publish","closed","closed","","news","","","2016-06-17 14:41:42","2016-06-17 21:41:42","","0","http://www.queenbeefundraising.com/?page_id=23","0","page","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("26","1","2016-06-17 14:41:42","2016-06-17 21:41:42"," ","","","publish","closed","closed","","26","","","2016-06-19 01:40:42","2016-06-19 08:40:42","","0","http://www.queenbeefundraising.com/?p=26","3","nav_menu_item","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("133","1","2016-06-17 14:41:42","2016-06-17 21:41:42","Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!","Hello world!","","inherit","closed","closed","","1-revision-v1","","","2016-06-17 14:41:42","2016-06-17 21:41:42","","1","http://www.queenbeefundraising.com/1-revision-v1/","0","revision","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("134","1","2016-06-17 14:41:42","2016-06-17 21:41:42","<strong>COMPANY NAME</strong> has been delivering results since we opened in <strong>YEAR</strong>. Our goal is to provide both a superior customer experience and tremendous value for our customers.\n\n<strong>OWNER NAME</strong> has over <strong>NUMBER</strong> years of experience in <strong>INDUSTRY NAME</strong> and is passionate about exceeding your expectations.\n\nWe love our customers and welcome your feedback and suggestions. Use our <a href=\"/contact/\" title=\"Contact Us\">Contact Us</a> page to tell us what we’re doing right or what we can improve on.","About Us","","inherit","closed","closed","","2-revision-v1","","","2016-06-17 14:41:42","2016-06-17 21:41:42","","2","http://www.queenbeefundraising.com/2-revision-v1/","0","revision","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("135","1","2016-06-17 14:41:42","2016-06-17 21:41:42","For your convenience, our most common customer questions are answered right here.\n\nNot finding what you want? Reach out directly through our <a href=\"/contact/\" title=\"Contact Us\">Contact Us</a> page.\n\n<strong>Q:</strong> <em>Add questions here.</em>\n\n<strong>A:</strong> Add answers here.","FAQ","","inherit","closed","closed","","9-revision-v1","","","2016-06-17 14:41:42","2016-06-17 21:41:42","","9","http://www.queenbeefundraising.com/9-revision-v1/","0","revision","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("136","1","2016-06-17 14:41:42","2016-06-17 21:41:42","Save time with a free, no-obligation quote.\n\nTell us the details of your project, and we’ll respond with an accurate quote and timeline for the work.\n\nNeed something else? Use our <a title=\"Contact Us\" href=\"/contact/\">Contact Us</a> page.\n\n[ninja_forms id=2]","Estimates","","inherit","closed","closed","","11-revision-v1","","","2016-06-17 14:41:42","2016-06-17 21:41:42","","11","http://www.queenbeefundraising.com/11-revision-v1/","0","revision","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("137","1","2016-06-17 14:41:42","2016-06-17 21:41:42","Our wonderful customers are the reason we’re in business. Here are some of the great things they’ve said about us.\n\nWe’ll do everything we can to make sure you’re a satisfied customer, too!\n\n<blockquote>Insert an amazing testimonial here. &mdash; Jane Doe</blockquote>","Testimonials","","inherit","closed","closed","","13-revision-v1","","","2016-06-17 14:41:42","2016-06-17 21:41:42","","13","http://www.queenbeefundraising.com/13-revision-v1/","0","revision","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("138","1","2016-06-17 14:41:42","2016-06-17 21:41:42","Customer feedback is the lifeblood of our business. Tell us what’s on your mind, good or bad.\n\nWe respond to all customer feedback and look forward to hearing from you!\n\n[ninja_forms id=1]","Contact Us","","inherit","closed","closed","","19-revision-v1","","","2016-06-17 14:41:42","2016-06-17 21:41:42","","19","http://www.queenbeefundraising.com/19-revision-v1/","0","revision","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("139","1","2016-06-17 14:41:42","2016-06-17 21:41:42","","News","","inherit","closed","closed","","23-revision-v1","","","2016-06-17 14:41:42","2016-06-17 21:41:42","","23","http://www.queenbeefundraising.com/23-revision-v1/","0","revision","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("140","1","2016-06-17 14:41:43","2016-06-17 21:41:43","","d288d822b73e03297f24d0dcd1c0bcbef89941f209f1415e76dfe0eaac98e6b0-v9k0Fb","","inherit","open","closed","","d288d822b73e03297f24d0dcd1c0bcbef89941f209f1415e76dfe0eaac98e6b0-v9k0fb","","","2016-06-17 14:41:43","2016-06-17 21:41:43","","0","http://www.queenbeefundraising.com/wp-content/uploads/2016/06/d288d822b73e03297f24d0dcd1c0bcbef89941f209f1415e76dfe0eaac98e6b0-v9k0Fb.jpeg","0","attachment","image/jpeg","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("141","1","2016-06-17 14:42:03","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2016-06-17 14:42:03","0000-00-00 00:00:00","","0","http://www.queenbeefundraising.com/?p=141","0","post","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("142","1","2016-06-17 14:42:04","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2016-06-17 14:42:04","0000-00-00 00:00:00","","0","http://www.queenbeefundraising.com/?p=142","0","post","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("150","1","2016-06-19 01:46:32","2016-06-19 08:46:32","This is an example of a WordPress post, you could edit this to put information about yourself or …","Sample Post 2","","inherit","closed","closed","","149-revision-v1","","","2016-06-19 01:46:32","2016-06-19 08:46:32","","149","http://www.queenbeefundraising.com/149-revision-v1/","0","revision","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("148","1","2016-06-19 01:45:24","2016-06-19 08:45:24","","woman-hand-desk-office","","inherit","open","closed","","woman-hand-desk-office","","","2016-06-19 01:45:24","2016-06-19 08:45:24","","1","http://www.queenbeefundraising.com/wp-content/uploads/2016/06/woman-hand-desk-office.jpg","0","attachment","image/jpeg","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("149","1","2016-06-19 01:46:32","2016-06-19 08:46:32","This is an example of a WordPress post, you could edit this to put information about yourself or …","Sample Post 2","","publish","open","open","","sample-post-2","","","2016-06-19 01:46:32","2016-06-19 08:46:32","","0","http://www.queenbeefundraising.com/?p=149","0","post","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("147","0","2016-06-17 15:03:56","2016-06-17 22:03:56","","Default Upgrade","","publish","closed","closed","","default-upgrade","","","2016-06-17 15:03:56","2016-06-17 22:03:56","","0","http://www.queenbeefundraising.com/default-upgrade/","0","content-upgrades","","0");
INSERT IGNORE INTO wp_fsyt4wavdq_posts VALUES("151","1","2016-06-19 01:48:46","2016-06-19 08:48:46","<strong>COMPANY NAME</strong> has been delivering results since we opened in <strong>YEAR</strong>. Our goal is to provide both a superior customer experience and tremendous value for our customers.\n\n<strong>OWNER NAME</strong> has over <strong>NUMBER</strong> years of experience in <strong>INDUSTRY NAME</strong> and is passionate about exceeding your expectations.\n\nWe love our customers and welcome your feedback and suggestions. Use our <a title=\"Contact Us\" href=\"/contact/\">Contact Us</a> page to tell us what we’re doing right or what we can improve on.","About Us","","inherit","closed","closed","","2-revision-v1","","","2016-06-19 01:48:46","2016-06-19 08:48:46","","2","http://www.queenbeefundraising.com/2-revision-v1/","0","revision","","0");




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
