-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:01
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_nf3_form_meta
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_nf3_form_meta LIMIT 0,10000
-- Offset : 0
-- Rows   : 27
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_nf3_form_meta`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_nf3_form_meta`;
CREATE TABLE `wp_fsyt4wavdq_nf3_form_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `key` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_fsyt4wavdq_nf3_form_meta`
--
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("1","1","objectType","Form Setting");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("2","1","editActive","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("3","1","show_title","0");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("4","1","clear_complete","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("5","1","hide_complete","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("6","1","currency","usd");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("7","1","add_submit","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("8","1","logged_in","0");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("9","2","objectType","Form Setting");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("10","2","editActive","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("11","2","show_title","0");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("12","2","clear_complete","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("13","2","hide_complete","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("14","2","currency","usd");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("15","2","add_submit","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("16","2","logged_in","0");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("17","2","lock","0");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("18","2","wrapper_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("19","2","element_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("20","2","not_logged_in_msg","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("21","2","sub_limit_number","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("22","2","sub_limit_msg","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("23","1","wrapper_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("24","1","element_class","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("25","1","not_logged_in_msg","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("26","1","sub_limit_number","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_form_meta VALUES("27","1","sub_limit_msg","");




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
