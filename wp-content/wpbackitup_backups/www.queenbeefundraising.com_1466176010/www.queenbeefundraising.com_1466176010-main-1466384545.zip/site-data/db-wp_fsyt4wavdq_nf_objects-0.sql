-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:01
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_nf_objects
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_nf_objects LIMIT 0,10000
-- Offset : 0
-- Rows   : 4
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_nf_objects`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_nf_objects`;
CREATE TABLE `wp_fsyt4wavdq_nf_objects` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;



--
-- Data for table `wp_fsyt4wavdq_nf_objects`
--
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objects VALUES("1","form");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objects VALUES("2","notification");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objects VALUES("3","notification");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_objects VALUES("4","notification");




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
