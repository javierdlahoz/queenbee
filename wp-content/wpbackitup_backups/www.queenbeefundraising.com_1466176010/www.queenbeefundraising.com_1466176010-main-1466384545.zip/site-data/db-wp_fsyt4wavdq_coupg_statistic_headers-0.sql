-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:02
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_coupg_statistic_headers
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_coupg_statistic_headers LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_coupg_statistic_headers`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_coupg_statistic_headers`;
CREATE TABLE `wp_fsyt4wavdq_coupg_statistic_headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stat_id` int(11) NOT NULL,
  `header_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stat_id` (`stat_id`),
  CONSTRAINT `wp_fsyt4wavdq_coupg_statistic_headers_ibfk_1` FOREIGN KEY (`stat_id`) REFERENCES `wp_fsyt4wavdq_coupg_statistic` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Data for table `wp_fsyt4wavdq_coupg_statistic_headers`
--




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
