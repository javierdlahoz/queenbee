-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:01
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_nf3_actions
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_nf3_actions LIMIT 0,10000
-- Offset : 0
-- Rows   : 6
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_nf3_actions`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_nf3_actions`;
CREATE TABLE `wp_fsyt4wavdq_nf3_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext COLLATE utf8mb4_unicode_ci,
  `key` longtext COLLATE utf8mb4_unicode_ci,
  `type` longtext COLLATE utf8mb4_unicode_ci,
  `active` tinyint(1) DEFAULT '1',
  `parent_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_fsyt4wavdq_nf3_actions`
--
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_actions VALUES("1","","","successmessage","1","1","2016-03-17 12:34:16","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_actions VALUES("2","","","email","1","1","2016-03-17 12:34:16","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_actions VALUES("3","","","save","1","1","2016-03-17 12:34:16","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_actions VALUES("4","","","successmessage","1","2","2016-03-17 12:34:16","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_actions VALUES("5","","","email","1","2","2016-03-17 12:34:16","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_actions VALUES("6","","","save","1","2","2016-03-17 12:34:16","");




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
