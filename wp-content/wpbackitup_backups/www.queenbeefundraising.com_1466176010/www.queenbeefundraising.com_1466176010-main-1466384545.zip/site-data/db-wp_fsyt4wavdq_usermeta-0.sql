-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:01
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_usermeta
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_usermeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 21
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_usermeta`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_usermeta`;
CREATE TABLE `wp_fsyt4wavdq_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_fsyt4wavdq_usermeta`
--
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("1","1","nickname","ajsteinberg");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("2","1","first_name","");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("3","1","last_name","");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("4","1","description","");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("5","1","rich_editing","true");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("6","1","comment_shortcuts","false");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("7","1","admin_color","fresh");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("8","1","use_ssl","0");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("9","1","show_admin_bar_front","true");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("10","1","wp_fsyt4wavdq_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("11","1","wp_fsyt4wavdq_user_level","10");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("12","1","dismissed_wp_pointers","wpem_theme_preview_1,wpem_theme_preview_2,wpem_theme_preview_3");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("13","1","show_welcome_panel","1");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("14","1","session_tokens","a:5:{s:64:\"e46b6eafd529b2073a8983ac1ba210ec05cc051e5069f373ddcad558eee53c6d\";a:4:{s:10:\"expiration\";i:1467198604;s:2:\"ip\";s:14:\"71.122.145.118\";s:2:\"ua\";s:113:\"Mozilla/5.0 (X11; CrOS armv7l 8172.47.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36\";s:5:\"login\";i:1465989004;}s:64:\"c83d73d2a9694de91abc48f4990939b9ab528fcb205741583017acf6194d733d\";a:4:{s:10:\"expiration\";i:1466371016;s:2:\"ip\";s:14:\"71.122.145.118\";s:2:\"ua\";s:113:\"Mozilla/5.0 (X11; CrOS armv7l 8172.47.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36\";s:5:\"login\";i:1466198216;}s:64:\"ee941d827ca87f1ac2367a90d05bf15c638d6d909653c663cdbcdb5ccb874121\";a:4:{s:10:\"expiration\";i:1466371080;s:2:\"ip\";s:14:\"71.122.145.118\";s:2:\"ua\";s:113:\"Mozilla/5.0 (X11; CrOS armv7l 8172.47.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36\";s:5:\"login\";i:1466198280;}s:64:\"8b5c7462a19906f810ca9aec5136d3d3bdcc9ab6f0bb97532c6e595a0ea7bd9e\";a:4:{s:10:\"expiration\";i:1467409236;s:2:\"ip\";s:14:\"71.122.145.118\";s:2:\"ua\";s:113:\"Mozilla/5.0 (X11; CrOS armv7l 8172.47.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36\";s:5:\"login\";i:1466199636;}s:64:\"0ff94fceef68933f55eefc5d8c262943a465269b5d75e63a7914e76d78b5e274\";a:4:{s:10:\"expiration\";i:1466498376;s:2:\"ip\";s:14:\"117.233.18.203\";s:2:\"ua\";s:72:\"Mozilla/5.0 (Windows NT 6.3; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0\";s:5:\"login\";i:1466325576;}}");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("15","1","sk_ignore_notice","1");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("16","1","wp_fsyt4wavdq_dashboard_quick_press_last_post_id","142");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("17","1","nav_menu_recently_edited","3");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("18","1","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("19","1","metaboxhidden_nav-menus","a:4:{i:0;s:20:\"add-post-type-nf_sub\";i:1;s:23:\"add-post-type-portfolio\";i:2;s:12:\"add-post_tag\";i:3;s:18:\"add-portfolio-type\";}");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("20","1","wp_fsyt4wavdq_user-settings","libraryContent=browse");
INSERT IGNORE INTO wp_fsyt4wavdq_usermeta VALUES("21","1","wp_fsyt4wavdq_user-settings-time","1466325931");




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
