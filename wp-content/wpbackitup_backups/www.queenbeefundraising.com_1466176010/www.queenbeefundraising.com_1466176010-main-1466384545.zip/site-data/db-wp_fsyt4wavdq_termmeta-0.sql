-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:01
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_termmeta
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_termmeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 11
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_termmeta`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_termmeta`;
CREATE TABLE `wp_fsyt4wavdq_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_fsyt4wavdq_termmeta`
--
INSERT IGNORE INTO wp_fsyt4wavdq_termmeta VALUES("1","3","headline","");
INSERT IGNORE INTO wp_fsyt4wavdq_termmeta VALUES("2","3","intro_text","");
INSERT IGNORE INTO wp_fsyt4wavdq_termmeta VALUES("3","3","display_title","0");
INSERT IGNORE INTO wp_fsyt4wavdq_termmeta VALUES("4","3","display_description","0");
INSERT IGNORE INTO wp_fsyt4wavdq_termmeta VALUES("5","3","doctitle","");
INSERT IGNORE INTO wp_fsyt4wavdq_termmeta VALUES("6","3","description","");
INSERT IGNORE INTO wp_fsyt4wavdq_termmeta VALUES("7","3","keywords","");
INSERT IGNORE INTO wp_fsyt4wavdq_termmeta VALUES("8","3","layout","");
INSERT IGNORE INTO wp_fsyt4wavdq_termmeta VALUES("9","3","noindex","0");
INSERT IGNORE INTO wp_fsyt4wavdq_termmeta VALUES("10","3","nofollow","0");
INSERT IGNORE INTO wp_fsyt4wavdq_termmeta VALUES("11","3","noarchive","0");




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
