-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:01
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_nf3_action_meta
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_nf3_action_meta LIMIT 0,10000
-- Offset : 0
-- Rows   : 114
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_nf3_action_meta`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_nf3_action_meta`;
CREATE TABLE `wp_fsyt4wavdq_nf3_action_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `key` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_fsyt4wavdq_nf3_action_meta`
--
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("1","1","label","Success Message");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("2","1","message","Your form has been successfully submitted.");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("3","1","order","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("4","1","objectType","Action");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("5","1","objectDomain","actions");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("6","1","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("7","1","payment_gateways","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("8","1","tag","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("9","1","to","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("10","1","email_subject","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("11","1","email_message","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("12","1","from_name","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("13","1","from_address","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("14","1","reply_to","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("15","1","email_format","html");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("16","1","cc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("17","1","bcc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("18","1","attach_csv","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("19","1","redirect_url","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("20","1","success_msg","<p>Thank you so much for contacting us. We will get back to you shortly.</p>");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("21","2","label","Admin Email");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("22","2","to","a:1:{i:0;s:27:\"noreply@501759c0-6637-494a-b3b4-8d6a0415e4c5.com\";}");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("23","2","subject","Ninja Forms Submission");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("24","2","message","{field:all_fields}");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("25","2","order","2");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("26","2","objectType","Action");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("27","2","objectDomain","actions");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("28","2","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("29","2","payment_gateways","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("30","2","tag","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("31","2","email_subject","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("32","2","email_message","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("33","2","from_name","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("34","2","from_address","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("35","2","reply_to","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("36","2","email_format","html");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("37","2","cc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("38","2","bcc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("39","2","attach_csv","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("40","3","label","Save Submission");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("41","3","order","3");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("42","3","objectType","Action");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("43","3","objectDomain","actions");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("44","3","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("45","3","payment_gateways","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("46","3","tag","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("47","3","to","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("48","3","email_subject","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("49","3","email_message","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("50","3","from_name","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("51","3","from_address","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("52","3","reply_to","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("53","3","email_format","html");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("54","3","cc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("55","3","bcc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("56","3","attach_csv","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("57","3","redirect_url","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("58","4","label","Success Message");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("59","4","message","Your form has been successfully submitted.");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("60","4","order","1");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("61","4","objectType","Action");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("62","4","objectDomain","actions");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("63","4","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("64","4","payment_gateways","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("65","4","tag","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("66","4","to","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("67","4","email_subject","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("68","4","email_message","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("69","4","from_name","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("70","4","from_address","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("71","4","reply_to","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("72","4","email_format","html");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("73","4","cc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("74","4","bcc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("75","4","attach_csv","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("76","4","redirect_url","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("77","4","success_msg","<p>Thank you so much for contacting us. We will get back to you shortly.</p>");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("78","5","label","Admin Email");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("79","5","to","a:1:{i:0;s:27:\"noreply@501759c0-6637-494a-b3b4-8d6a0415e4c5.com\";}");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("80","5","subject","Ninja Forms Submission");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("81","5","message","{field:all_fields}");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("82","5","order","2");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("83","5","objectType","Action");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("84","5","objectDomain","actions");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("85","5","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("86","5","payment_gateways","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("87","5","tag","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("88","5","email_subject","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("89","5","email_message","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("90","5","from_name","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("91","5","from_address","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("92","5","reply_to","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("93","5","email_format","html");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("94","5","cc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("95","5","bcc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("96","5","attach_csv","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("97","6","label","Save Submission");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("98","6","order","3");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("99","6","objectType","Action");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("100","6","objectDomain","actions");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("101","6","editActive","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("102","6","payment_gateways","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("103","6","tag","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("104","6","to","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("105","6","email_subject","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("106","6","email_message","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("107","6","from_name","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("108","6","from_address","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("109","6","reply_to","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("110","6","email_format","html");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("111","6","cc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("112","6","bcc","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("113","6","attach_csv","");
INSERT IGNORE INTO wp_fsyt4wavdq_nf3_action_meta VALUES("114","6","redirect_url","");




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
