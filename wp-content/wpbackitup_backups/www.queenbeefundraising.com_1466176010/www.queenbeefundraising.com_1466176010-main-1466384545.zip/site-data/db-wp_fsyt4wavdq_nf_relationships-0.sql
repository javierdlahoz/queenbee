-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:01
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_nf_relationships
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_nf_relationships LIMIT 0,10000
-- Offset : 0
-- Rows   : 3
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_nf_relationships`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_nf_relationships`;
CREATE TABLE `wp_fsyt4wavdq_nf_relationships` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `child_id` bigint(20) NOT NULL,
  `parent_id` bigint(20) NOT NULL,
  `child_type` varchar(255) NOT NULL,
  `parent_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;



--
-- Data for table `wp_fsyt4wavdq_nf_relationships`
--
INSERT IGNORE INTO wp_fsyt4wavdq_nf_relationships VALUES("1","2","1","notification","form");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_relationships VALUES("2","3","1","notification","form");
INSERT IGNORE INTO wp_fsyt4wavdq_nf_relationships VALUES("3","4","1","notification","form");




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
