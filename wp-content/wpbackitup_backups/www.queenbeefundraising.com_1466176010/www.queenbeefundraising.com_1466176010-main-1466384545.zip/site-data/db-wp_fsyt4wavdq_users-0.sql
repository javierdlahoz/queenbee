-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Manual Database Export 
--
-- Created: 2016/06/20 on 08:02
--
-- Database : n5013396405301
--
-- Table : wp_fsyt4wavdq_users
--
-- SQL    : SELECT * FROM wp_fsyt4wavdq_users LIMIT 0,10000
-- Offset : 0
-- Rows   : 1
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Table structure for table `wp_fsyt4wavdq_users`
--
DROP TABLE  IF EXISTS `wp_fsyt4wavdq_users`;
CREATE TABLE `wp_fsyt4wavdq_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_fsyt4wavdq_users`
--
INSERT IGNORE INTO wp_fsyt4wavdq_users VALUES("1","ajsteinberg","$P$BsZ1yywjAqBt4Uf.sAGR/YuGZzKW/H0","ajsteinberg","ajsteinberg@aol.com","","2016-06-14 22:37:53","","0","ajsteinberg");




SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
